import java.io.*;
import java.net.*;
import java.util.Scanner;

public class Client {
    public static void main(String[] args) {
        try {
            Socket socket = new Socket("127.0.0.1", 49152);
            System.out.println("Connected to Server!");

            BufferedReader in = new BufferedReader(
                    new InputStreamReader(
                            socket.getInputStream()
                    )
            );
            PrintWriter out = new PrintWriter(
                    socket.getOutputStream(), true
            );

            while (true) {

                System.out.print("Enter command: ");
                Scanner scanner = new Scanner(System.in);

                String request = scanner.nextLine();
                System.out.println("[SEND] Requesting: " + request);
                out.println(request);

                if (request.equalsIgnoreCase("END")) {
                    System.out.println("ending...");
                    break;
                }

                String response = in.readLine();
                System.out.println("[RECEIVE] Server replied: " + response);

            }

            socket.close();

        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
