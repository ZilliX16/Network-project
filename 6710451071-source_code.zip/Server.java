import java.io.*;
import java.net.*;

public class Server {
    public static void main(String[] args) {

        try {
            ServerSocket serverSocket = new ServerSocket(49152);
            System.out.println("Server is waiting on port 49152...");

            Socket clientSocket = serverSocket.accept();
            System.out.println("Client connected!");

            BufferedReader in = new BufferedReader(
                    new InputStreamReader(
                            clientSocket.getInputStream()
                    )
            );
            PrintWriter out = new PrintWriter(
                    clientSocket.getOutputStream(), true
            );

            while (true) {

                String request = in.readLine();
                System.out.println("[RECEIVE] Command from Client: " + request);

                if(request.equalsIgnoreCase("END")) {
                    System.out.println("ending...");
                    break;
                }

                String response = processRequest(request);

                System.out.println("[SEND] Reply to Client: " + response);
                out.println(response);

            }

            clientSocket.close();
            serverSocket.close();

        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private static String processRequest(String request) {
        if (request == null) {
            return "400 Bad Request | Empty request.";
        }

        try {
            String[] parts = request.split(" ");

            if (parts.length != 3) {
                return "400 Bad Request | Invalid format. Usage: <CMD> <NUM1> <NUM2>";
            }
            String command = parts[0].toUpperCase();

            double num1 = Double.parseDouble(parts[1]);
            double num2 = Double.parseDouble(parts[2]);

            double result = 0;

            switch (command) {
                case "END" -> {
                    return "400 Bad Request | Command 'END' expects no parameters.";
                }
                case "ADD" -> result = num1 + num2;
                case "SUB" -> result = num1 - num2;
                case "MUL" -> result = num1 * num2;
                case "DIV" -> {
                    if (num2 == 0) {
                        return "403 Forbidden | Cannot divide by zero.";
                    }
                    result = num1 / num2;
                }
                default -> {
                    return "400 Bad Request | Unknown Command '" + command + "'";
                }
            }

            return "200 OK | Result: " + result;

        } catch (NumberFormatException e) {
            return "406 Not Acceptable | Parameters must be numbers.";
        }
    }
}
